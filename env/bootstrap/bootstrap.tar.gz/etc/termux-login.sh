##
## This script is sourced by /data/data/com.cc.ide/files/usr/bin/login before executing shell.
##
