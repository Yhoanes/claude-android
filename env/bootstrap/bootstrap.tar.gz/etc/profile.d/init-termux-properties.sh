if [ ! -f /data/data/com.cc.ide/files/home/.config/termux/termux.properties ] && [ ! -e /data/data/com.cc.ide/files/home/.termux/termux.properties ]; then
	mkdir -p /data/data/com.cc.ide/files/home/.termux
	cp /data/data/com.cc.ide/files/usr/share/examples/termux/termux.properties /data/data/com.cc.ide/files/home/.termux/
fi
